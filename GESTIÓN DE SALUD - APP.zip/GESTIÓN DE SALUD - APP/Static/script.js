// agregar interacciones dinámicas, por ejemplo:
document.addEventListener('DOMContentLoaded', function() {
    console.log('Aplicación cargada correctamente');
});
